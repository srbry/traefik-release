package dependency

func init() {
	VaultDefaultLeaseDuration = 0
}
